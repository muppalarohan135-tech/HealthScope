
import React from 'react';
import { MedicalStory } from '../types';

interface StoryCardProps {
  story: MedicalStory;
  onClick: (story: MedicalStory) => void;
  onDelete?: (id: string) => void;
}

export const StoryCard: React.FC<StoryCardProps> = ({ story, onClick, onDelete }) => {
  return (
    <div 
      onClick={() => onClick(story)}
      className="group relative cursor-pointer bg-white rounded-3xl overflow-hidden soft-shadow transition-transform duration-300 hover:-translate-y-2 border border-stone-100"
    >
      {onDelete && (
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onDelete(story.id);
          }}
          title="Delete Article"
          className="absolute top-4 right-4 z-20 p-2.5 bg-red-50/90 backdrop-blur-md text-red-600 rounded-full hover:bg-red-500 hover:text-white transition-all shadow-sm border border-red-100 active:scale-90"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      )}

      <div className="relative h-56 overflow-hidden">
        <img 
          src={story.imageUrl} 
          alt={story.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4">
          <span className="px-4 py-1.5 bg-white/90 backdrop-blur-md text-[#8B735B] text-xs font-semibold rounded-full shadow-sm">
            {story.category}
          </span>
        </div>
      </div>
      <div className="p-8">
        <div className="flex items-center text-xs text-[#A68B6D] mb-3 space-x-2">
          <span>{story.date}</span>
          <span>•</span>
          <span>{story.readTime}</span>
        </div>
        <h3 className="text-2xl font-bold text-[#3E2723] mb-3 leading-tight group-hover:text-[#8B735B] transition-colors">
          {story.title}
        </h3>
        <p className="text-[#6D5D54] line-clamp-2 text-sm leading-relaxed mb-4">
          {story.excerpt}
        </p>
        <div className="flex items-center space-x-2">
           <div className="w-6 h-6 rounded-full bg-stone-100 border border-stone-200"></div>
           <span className="text-xs font-medium text-[#8B735B]">by {story.author}</span>
        </div>
      </div>
    </div>
  );
};
