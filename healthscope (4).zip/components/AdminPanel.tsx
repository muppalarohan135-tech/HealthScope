
import React, { useState, useRef } from 'react';
import { Category, MedicalStory } from '../types';

interface AdminPanelProps {
  onAddStory: (story: MedicalStory) => void;
  onClose: () => void;
  allStories: MedicalStory[];
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onAddStory, onClose, allStories }) => {
  const [password, setPassword] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showExport, setShowExport] = useState(false);
  
  // Manual field states
  const [title, setTitle] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [readTime, setReadTime] = useState('5 min read');
  const [author, setAuthor] = useState('');
  const [category, setCategory] = useState<Category>(Category.PREVENTION);
  const [imageUrl, setImageUrl] = useState('');
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'rwq234') {
      setIsUnlocked(true);
    } else {
      alert('Incorrect password');
    }
  };

  const insertMedia = (type: 'IMG' | 'VID') => {
    const url = prompt(`Enter ${type === 'IMG' ? 'Image' : 'Video'} URL:`);
    if (!url) return;
    
    const tag = `[[${type}:${url}]]`;
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const before = text.substring(0, start);
    const after = text.substring(end, text.length);
    
    setContent(before + tag + after);
    
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + tag.length;
    }, 0);
  };

  const handlePublish = () => {
    if (!title.trim() || !content.trim()) {
      alert("Please provide at least a title and content.");
      return;
    }

    const newStory: MedicalStory = {
      id: Date.now().toString(),
      title,
      excerpt: excerpt || title.substring(0, 100) + '...',
      content,
      category,
      author: author || 'HealthScope Contributor',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      imageUrl: imageUrl || `https://picsum.photos/seed/${Date.now()}/1200/800`,
      readTime: readTime || '5 min read'
    };

    onAddStory(newStory);
    alert("Published locally! To make this permanent for ALL visitors, use the 'Export for Global View' tool in the bottom left.");
    // Clear fields
    setTitle(''); setContent(''); setExcerpt(''); setImageUrl('');
  };

  const copyToClipboard = () => {
    const data = JSON.stringify(allStories, null, 2);
    navigator.clipboard.writeText(data);
    alert("JSON Copied! Now paste this into your constants.tsx file under INITIAL_STORIES to make it permanent for everyone.");
  };

  if (!isUnlocked) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#3E2723]/40 backdrop-blur-sm">
        <div className="bg-[#FDFBF7] w-full max-w-md rounded-[2rem] p-8 soft-shadow border border-stone-100">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-[#3E2723]">Admin Access</h2>
            <p className="text-[#8B735B] text-sm mt-2 font-medium">Verify credentials to edit the HealthScope portal.</p>
          </div>
          <form onSubmit={handleUnlock} className="space-y-4">
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password..."
              className="w-full px-5 py-3 rounded-2xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white text-[#3E2723]"
              autoFocus
            />
            <button type="submit" className="w-full py-3 rounded-full font-bold text-white bg-[#8B735B] hover:bg-[#7a644f] transition-all shadow-md">Unlock Portal</button>
            <button type="button" onClick={onClose} className="w-full py-2 text-[#8B735B] text-sm font-semibold hover:underline">Return to Reader View</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#3E2723]/40 backdrop-blur-sm">
      <div className="bg-[#FDFBF7] w-full max-w-6xl rounded-[3rem] p-8 soft-shadow border border-stone-100 overflow-y-auto max-h-[95vh] relative">
        <div className="flex justify-between items-start mb-10">
          <div>
            <h2 className="text-4xl font-bold text-[#3E2723]">Content Studio</h2>
            <p className="text-[#8B735B] text-sm font-semibold mt-1">Drafting stories for the permanent scope</p>
          </div>
          <button onClick={onClose} className="p-3 bg-stone-50 hover:bg-stone-100 rounded-full transition-colors text-[#8B735B] border border-stone-200">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Side: Setup & Title Panel Preview */}
          <div className="lg:col-span-5 space-y-8">
            <section className="space-y-6">
              <div className="bg-stone-50/50 p-6 rounded-[2rem] border border-stone-100 space-y-4">
                <h3 className="text-xs font-black text-[#8B735B] uppercase tracking-[0.2em] mb-4">1. Hero Configuration</h3>
                
                <div>
                  <label className="block text-[10px] font-black text-[#8B735B] uppercase tracking-[0.2em] mb-2 ml-2">Header Image URL (The Title Panel)</label>
                  <input 
                    type="text" 
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="Paste Unsplash or medical image URL..."
                    className="w-full px-5 py-3 rounded-2xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white text-[#3E2723] text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-[#8B735B] uppercase tracking-[0.2em] mb-2 ml-2">Topic</label>
                    <select 
                      value={category}
                      onChange={(e) => setCategory(e.target.value as Category)}
                      className="w-full px-5 py-3 rounded-2xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white text-[#3E2723] text-sm font-bold"
                    >
                      {Object.values(Category).map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-[#8B735B] uppercase tracking-[0.2em] mb-2 ml-2">Author</label>
                    <input 
                      type="text" 
                      value={author}
                      onChange={(e) => setAuthor(e.target.value)}
                      placeholder="Name..."
                      className="w-full px-5 py-3 rounded-2xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white text-[#3E2723] text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Real-time Title Panel Preview */}
              <div className="space-y-4">
                 <h3 className="text-xs font-black text-[#8B735B] uppercase tracking-[0.2em] ml-2">Live Header Preview</h3>
                 <div className="relative h-72 w-full rounded-[2.5rem] overflow-hidden soft-shadow bg-stone-200 border border-stone-200 group">
                    {imageUrl ? (
                      <img src={imageUrl} className="w-full h-full object-cover" alt="Preview" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-stone-400 italic text-sm">Add a Header Image URL above...</div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#3E2723]/80 via-transparent to-transparent flex flex-col justify-end p-8">
                      <span className="text-white/80 text-[10px] font-black uppercase tracking-[0.2em] mb-2">{category}</span>
                      <h4 className="text-2xl font-bold text-white leading-tight">
                        {title || 'Your Insight Title Here...'}
                      </h4>
                    </div>
                 </div>
              </div>

              {/* Data Persistence Tools */}
              <div className="mt-12 p-6 bg-[#3E2723]/5 rounded-[2rem] border border-[#3E2723]/10">
                <h4 className="text-sm font-bold text-[#3E2723] mb-2">Global Visibility Tool</h4>
                <p className="text-xs text-[#8B735B] mb-4 leading-relaxed">To make your stories stay "forever" for every single visitor, you must Export the JSON and update your code constants.</p>
                <button 
                  onClick={() => setShowExport(!showExport)}
                  className="w-full py-3 border border-[#8B735B] text-[#8B735B] rounded-full text-xs font-black uppercase tracking-widest hover:bg-[#8B735B] hover:text-white transition-all"
                >
                  {showExport ? 'Hide Export Tools' : 'Export for Global View'}
                </button>
                
                {showExport && (
                  <div className="mt-4 space-y-3">
                    <button 
                      onClick={copyToClipboard}
                      className="w-full py-3 bg-white text-[#3E2723] rounded-2xl text-[10px] font-bold border border-stone-200 shadow-sm flex items-center justify-center space-x-2"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
                      <span>Copy All Stories as JSON</span>
                    </button>
                    <p className="text-[9px] text-center text-[#A68B6D] font-medium italic">Paste into constants.tsx -> INITIAL_STORIES</p>
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* Right Side: Narrative Editor */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-[#8B735B] uppercase tracking-[0.2em] mb-3 ml-2">Headline</label>
                <input 
                  type="text" 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="The Heart of Healing..."
                  className="w-full px-8 py-5 rounded-[2rem] border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white text-[#3E2723] text-2xl font-bold placeholder:text-stone-300 shadow-sm"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-[#8B735B] uppercase tracking-[0.2em] mb-3 ml-2">Brief Hook</label>
                <textarea 
                  rows={2}
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  placeholder="A one-sentence hook for the feed..."
                  className="w-full px-6 py-4 rounded-2xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white text-[#3E2723] resize-none italic text-sm leading-relaxed shadow-sm"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-3 ml-2">
                  <label className="block text-[10px] font-black text-[#8B735B] uppercase tracking-[0.2em]">Full Narrative</label>
                  <div className="flex space-x-2">
                    <button onClick={() => insertMedia('IMG')} className="px-3 py-2 bg-white text-[#8B735B] rounded-lg text-[10px] font-black border border-stone-200 hover:bg-stone-50 transition-colors">IMG</button>
                    <button onClick={() => insertMedia('VID')} className="px-3 py-2 bg-white text-[#8B735B] rounded-lg text-[10px] font-black border border-stone-200 hover:bg-stone-50 transition-colors">VID</button>
                  </div>
                </div>
                <textarea 
                  ref={textareaRef}
                  rows={12}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Tell the story here. Use standard spacing. Use the IMG/VID buttons to embed visuals..."
                  className="w-full px-8 py-8 rounded-[2.5rem] border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#8B735B]/20 bg-white resize-none text-[#3E2723] leading-[1.8] text-lg shadow-inner"
                />
              </div>
            </div>

            <button 
              onClick={handlePublish}
              className="w-full py-5 rounded-full font-bold text-white bg-[#8B735B] hover:bg-[#7a644f] active:scale-[0.98] transition-all shadow-xl text-lg flex items-center justify-center space-x-3"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              <span>Publish Locally</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
