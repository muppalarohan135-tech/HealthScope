
import React from 'react';
import { MedicalStory } from '../types';

interface StoryModalProps {
  story: MedicalStory;
  onClose: () => void;
}

export const StoryModal: React.FC<StoryModalProps> = ({ story, onClose }) => {
  const renderContent = (content: string) => {
    const parts = content.split(/(\[\[(?:IMG|VID):.*?\]\])/g);
    
    return parts.map((part, index) => {
      const imgMatch = part.match(/\[\[IMG:(.*?)\]\]/);
      const vidMatch = part.match(/\[\[VID:(.*?)\]\]/);

      if (imgMatch) {
        return (
          <div key={index} className="my-12 rounded-[2.5rem] overflow-hidden soft-shadow border border-stone-100 group">
            <img src={imgMatch[1]} alt="Supporting visual" className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105" />
          </div>
        );
      } else if (vidMatch) {
        return (
          <div key={index} className="my-12 rounded-[2.5rem] overflow-hidden soft-shadow bg-stone-900 aspect-video flex items-center justify-center border border-stone-100">
            <video src={vidMatch[1]} controls className="w-full h-full" />
          </div>
        );
      } else {
        return part.split('\n').map((line, lineIdx) => (
          <p key={`${index}-${lineIdx}`} className={line.trim() ? "mb-8 text-[#3E2723] leading-[1.8] text-lg font-medium opacity-90" : ""}>
            {line}
          </p>
        ));
      }
    });
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-0 md:p-8 bg-[#3E2723]/60 backdrop-blur-xl">
      <div className="bg-[#FDFBF7] w-full max-w-5xl h-full md:h-auto md:max-h-[92vh] md:rounded-[3.5rem] overflow-hidden soft-shadow relative flex flex-col border border-white/20">
        
        {/* Fixed Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 z-[70] p-4 bg-white/10 hover:bg-white/30 backdrop-blur-3xl rounded-full text-white transition-all shadow-xl active:scale-90 border border-white/20"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="overflow-y-auto scrollbar-hide flex-1">
          {/* Enhanced Title Panel */}
          <div className="relative h-[60vh] md:h-[70vh] w-full flex items-end">
            <div className="absolute inset-0">
              <img src={story.imageUrl} alt={story.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#FDFBF7] via-[#FDFBF7]/40 to-black/30"></div>
            </div>
            
            <div className="relative z-10 px-8 md:px-20 pb-12 md:pb-20 w-full">
              <div className="flex flex-wrap items-center gap-3 mb-6">
                <span className="px-5 py-2 bg-white/90 backdrop-blur-md border border-stone-200 text-[#8B735B] text-xs font-black uppercase tracking-[0.2em] rounded-full shadow-sm">
                  {story.category}
                </span>
                <span className="px-4 py-2 bg-[#8B735B] text-white text-[10px] font-bold rounded-full shadow-sm">
                  {story.readTime}
                </span>
              </div>
              
              <h1 className="text-4xl md:text-7xl font-bold text-[#3E2723] mb-8 leading-[1.1] tracking-tight max-w-4xl">
                {story.title}
              </h1>

              <div className="flex items-center space-x-6">
                 <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-[#8B735B]/10 border border-[#8B735B]/20 flex items-center justify-center text-[#8B735B] font-bold text-sm">
                       {story.author.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-black text-[#3E2723]">{story.author}</p>
                      <p className="text-[10px] text-[#8B735B] uppercase font-bold tracking-widest">{story.date}</p>
                    </div>
                 </div>
              </div>
            </div>
          </div>

          <div className="px-8 md:px-20 py-12 bg-[#FDFBF7]">
            <div className="max-w-4xl">
              {/* Excerpt as a soft blockquote */}
              <div className="relative mb-16 p-8 md:p-12 rounded-[2.5rem] bg-stone-50 border border-stone-100 shadow-inner">
                 <div className="absolute -top-4 -left-4 w-12 h-12 bg-[#8B735B] rounded-2xl flex items-center justify-center text-white text-3xl font-serif">“</div>
                 <p className="text-2xl md:text-3xl text-[#6D5D54] leading-relaxed font-light italic opacity-90">
                  {story.excerpt}
                </p>
              </div>

              <div className="article-content">
                {renderContent(story.content)}
              </div>
            </div>

            <div className="mt-20 pt-12 border-t border-stone-100 flex flex-col md:flex-row justify-between items-center gap-8">
              <div>
                <p className="text-[#A68B6D] text-xs font-bold uppercase tracking-widest mb-2">HealthScope Medicine Portal</p>
                <p className="text-[#A68B6D]/60 text-xs italic">All medical narratives are for informational purposes only. Consult a professional for health advice.</p>
              </div>
              <div className="flex items-center space-x-3">
                <button className="px-6 py-3 bg-white border border-stone-100 rounded-full text-sm font-bold text-[#8B735B] hover:bg-stone-50 transition-all shadow-sm">Save Insight</button>
                <button className="px-6 py-3 bg-[#8B735B] rounded-full text-sm font-bold text-white hover:bg-[#3E2723] transition-all shadow-lg">Share Now</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
