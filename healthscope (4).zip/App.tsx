
import React, { useState, useEffect, useMemo } from 'react';
import { Category, MedicalStory } from './types';
import { INITIAL_STORIES } from './constants';
import { StoryCard } from './components/StoryCard';
import { AdminPanel } from './components/AdminPanel';
import { StoryModal } from './components/StoryModal';

const App: React.FC = () => {
  const [stories, setStories] = useState<MedicalStory[]>(() => {
    const saved = localStorage.getItem('healthscope_stories');
    const localStories = saved ? JSON.parse(saved) : [];
    
    // Merge hardcoded stories with local stories, prioritizing IDs
    const merged = [...localStories];
    INITIAL_STORIES.forEach((hardcoded: MedicalStory) => {
      if (!merged.find(s => s.id === hardcoded.id)) {
        merged.push(hardcoded);
      }
    });
    
    return merged.length > 0 ? merged : INITIAL_STORIES;
  });

  const [isAdmin, setIsAdmin] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [selectedStory, setSelectedStory] = useState<MedicalStory | null>(null);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('healthscope_stories', JSON.stringify(stories));
  }, [stories]);

  const filteredStories = useMemo(() => {
    const sorted = [...stories].sort((a, b) => Number(b.id) - Number(a.id));
    if (selectedCategory === 'All') return sorted;
    return sorted.filter(s => s.category === selectedCategory);
  }, [stories, selectedCategory]);

  const addStory = (newStory: MedicalStory) => {
    setStories(prev => [newStory, ...prev]);
  };

  const deleteStory = (id: string) => {
    if (window.confirm('Delete this health insight permanently?')) {
      setStories(prev => prev.filter(s => s.id !== id));
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-[#8B735B]/20 text-[#3E2723]">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur-xl border-b border-stone-100 px-6 py-5">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-[#8B735B] rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-sm">H</div>
            <h1 className="text-2xl font-bold tracking-tight text-[#3E2723]">
              HEALTH<span className="text-[#8B735B]">SCOPE</span>
            </h1>
          </div>

          <nav className="hidden md:flex items-center space-x-8 text-sm font-semibold text-[#8B735B]">
            <a href="#" className="hover:text-[#3E2723] transition-colors">Insights</a>
            <a href="#" className="hover:text-[#3E2723] transition-colors">Clinical Hub</a>
            <a href="#" className="hover:text-[#3E2723] transition-colors">Resources</a>
          </nav>

          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setIsAdmin(!isAdmin)}
              className={`px-5 py-2 rounded-full text-xs font-bold transition-all border ${isAdmin ? 'bg-[#8B735B] text-white shadow-lg border-transparent' : 'bg-stone-50 text-[#8B735B] border-stone-100 hover:bg-stone-100'}`}
            >
              {isAdmin ? 'ADMIN VIEW' : 'READER VIEW'}
            </button>
            {isAdmin && (
              <button 
                onClick={() => setIsAdminPanelOpen(true)}
                className="bg-[#3E2723] text-white p-2.5 rounded-xl hover:bg-black transition-all shadow-lg active:scale-95"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-16">
        {/* Soft Hero */}
        <section className="mb-24 text-center max-w-4xl mx-auto">
          <span className="inline-block px-5 py-2 bg-stone-100 border border-stone-200 text-[#8B735B] text-[10px] font-black rounded-full mb-8 uppercase tracking-[0.2em]">Portal for Medical Narratives</span>
          <h2 className="text-5xl md:text-8xl font-bold text-[#3E2723] mb-10 leading-[0.95] tracking-tight">
            Soft Wisdom for <span className="italic serif text-[#8B735B]">Hard Science.</span>
          </h2>
          <p className="text-xl md:text-2xl text-[#6D5D54] font-medium leading-relaxed max-w-2xl mx-auto">
            Accurate medical perspectives, written with empathy and clarity. Exploring the pulse of human health.
          </p>
        </section>

        {/* Dynamic Filters */}
        <section className="mb-16 flex flex-wrap items-center gap-3">
          <button 
            onClick={() => setSelectedCategory('All')}
            className={`px-8 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${selectedCategory === 'All' ? 'bg-[#8B735B] text-white' : 'bg-white text-[#8B735B] border border-stone-100 hover:bg-stone-50'}`}
          >
            All Narratives
          </button>
          {Object.values(Category).map(cat => (
            <button 
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-8 py-3 rounded-full text-sm font-bold transition-all shadow-sm ${selectedCategory === cat ? 'bg-[#8B735B] text-white' : 'bg-white text-[#8B735B] border border-stone-100 hover:bg-stone-50'}`}
            >
              {cat}
            </button>
          ))}
        </section>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {filteredStories.length > 0 ? (
            filteredStories.map(story => (
              <StoryCard 
                key={story.id} 
                story={story} 
                onClick={setSelectedStory}
                onDelete={isAdmin ? deleteStory : undefined}
              />
            ))
          ) : (
            <div className="col-span-full py-32 text-center bg-stone-50 rounded-[3rem] border border-stone-100 border-dashed">
              <h3 className="text-3xl font-bold text-[#3E2723]">The scope is clear today.</h3>
              <p className="text-[#8B735B] mt-3 font-medium text-lg">Switch to Admin View to document new medical insights.</p>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-[#3E2723] text-white py-24 px-6 rounded-t-[4rem]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-16">
          <div className="max-w-md">
            <h3 className="text-3xl font-bold mb-6">HEALTHSCOPE</h3>
            <p className="text-white/60 leading-relaxed font-medium text-lg">
              Empowering individuals through medical storytelling and clinical insights. A world where science feels like home.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-12">
            <div>
              <h4 className="font-bold mb-6 uppercase tracking-widest text-xs text-white/40">Navigation</h4>
              <ul className="space-y-4 font-semibold">
                <li><a href="#" className="hover:text-[#8B735B]">Clinical Hub</a></li>
                <li><a href="#" className="hover:text-[#8B735B]">Resources</a></li>
                <li><a href="#" className="hover:text-[#8B735B]">About Scope</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6 uppercase tracking-widest text-xs text-white/40">Legal</h4>
              <ul className="space-y-4 font-semibold text-white/60 text-sm">
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Disclaimer</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>

      {isAdminPanelOpen && (
        <AdminPanel 
          onAddStory={addStory} 
          onClose={() => setIsAdminPanelOpen(false)} 
          allStories={stories}
        />
      )}
      {selectedStory && (
        <StoryModal 
          story={selectedStory} 
          onClose={() => setSelectedStory(null)} 
        />
      )}
    </div>
  );
};

export default App;
